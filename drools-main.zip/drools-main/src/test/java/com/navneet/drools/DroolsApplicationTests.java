package com.navneet.drools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DroolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
